/**
 * import flutter material design
 * text, container, scaffold, etc
 */
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  //starting point of every dart file

  runApp(const SimplePortfolioApp());
  // flutter function that launch our application
  // function - stand alone block of code
  // method - function that define w/in a class that operates on objects data
  // This -> MyApp() - your application 
}

class SimplePortfolioApp extends StatelessWidget {
  /**
   * class name
   * does not change after building application
   */
  const SimplePortfolioApp({Key? key}) : super(key: key); 

  @override
  Widget build (BuildContext context) {
    return MaterialApp (
      debugShowCheckedModeBanner: false, //removes debug bunner
      title: 'Portfolio', // title
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0x0A0A0A),
      ),
      home: HomePage(), 
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  /**
   * State -> returns the object
   * State for the HomePage class
   * createState = Method
   */
  @override
  State<HomePage> createState() => _HomePageState();
  // _HomePageState (private = '_') ->  holds data that can change, trigger rebuild our app
}

class _HomePageState extends State<HomePage> {
  String selectedPage = 'Home';
  late ScrollController _scrollController;

  /**
   * Called once when widget is created
   * Perfect for creating controllers
   * Setup that happens before UI builds
   */
  @override initState() {
    super.initState();
    _scrollController = ScrollController();
  }

  Widget _buildContent() {
  if (selectedPage == 'Home') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ClipOval(
          child: Image.asset(
            'lib/assets/images/MyProfile.jpg',
            width: 120,
            height: 120,
            fit: BoxFit.cover,
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Orphiano, Noel Rafael J.',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'Flutter Developer',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  else if(selectedPage == 'About') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'I like Coding!',
          style: GoogleFonts.poppins(
            fontSize: 25,
            fontWeight: FontWeight.bold,
          ),
        ),
        Image.asset(
          'lib/assets/images/Coding.jpg',
          width: 240,
          height: 220,
          fit: BoxFit.cover,
        ),
        SizedBox(height: 8),
        Text(
          ' Currently studying at STI College Caloocan taking BS in Computer Science'
          ' Aspiring to become a Great Developer',
          style: GoogleFonts.poppins(
            fontSize: 11,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'I am a Catholic Christian',
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        Image.asset(
          'lib/assets/images/LordJesusChrist.jpg',
          width: 240,
          height: 220,
          fit: BoxFit.cover,
        ),
        SizedBox(height: 8),
        Text(
          'I was born as a Catholic Christian as well.'
          ' Devout Catholic and believes in the true Presence in the Eucharist'
          ' I like theology, learning about church history, and watching debates',
          style: GoogleFonts.poppins(
            fontSize: 11,
            color: Colors.black,
          ),
        ),
      ],
    );
  }

  else if(selectedPage == 'Skills') {
    //coming later
  }

  else if(selectedPage == 'Contact') {
    //coming later
  }

  return Text('Coming soon: $selectedPage');
}

  @override
  Widget build (BuildContext context) {
    // page structure (hold Appbar, drawer, body)
    return Scaffold(
      backgroundColor:Color(0xFFF5F5F5),
      appBar: AppBar(
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        title: Text(
          'Portfolio',
          style: GoogleFonts.poppins(
            fontSize: 20, 
            fontWeight: FontWeight.w600
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ClipOval(
                    child: Image.asset(
                      'lib/assets/images/MyProfile.jpg',
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    ),
                  ),
                  Text(
                    'Orphiano, Noel Rafael J.',
                    style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    )
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Flutter Developer',
                    style: GoogleFonts.roboto(
                    fontSize: 14,
                    color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.blue),
              title: Text('Home'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  selectedPage = 'Home';
                });
              },
            ),
            ListTile(
              leading: Icon(Icons.person, color: Colors.blue),
              title: Text('About'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  selectedPage = 'About';
                });
              },
            ),
            ListTile(
              leading: Icon(Icons.lightbulb, color: Colors.blue),
              title: Text('Skills'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  selectedPage = 'Skills';                  
                });
              },
            ),
            ListTile(
              leading: Icon(Icons.lightbulb, color: Colors.blue),
              title: Text('Contact'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  selectedPage = 'Contact';
                });
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.download, color: Colors.blue),
              title: Text('Download Resume'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  print('Download Resume tapped');
                });
              }
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        controller: _scrollController,
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(
            child: _buildContent(),
          ),
        ),
      ),
    );
  }

  /**
   * Called when widget is removed permanently
   * Cleanup to prevent memory leaks
   * Release resources (controllers, listeners, etc.)
   */
  @override
  void dispose() {
    super.dispose();
  }

  /**
   * Code organization order:
   * 1. State variables declaration
   * 2. initState() method
   * 3. Custom methods (_buildContent, etc.)
   * 4. build() method
   * 5. dispose() method
   * 
   * Why this order?
   * Variables at top → Easy to find
   * initState before build → Logical flow
   * Custom methods before build → Used by build
   * dispose at end → Cleanup last
   */
}